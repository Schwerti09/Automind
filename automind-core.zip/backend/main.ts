// AUTOMIND Mainserver
import { Application, Router } from "https://deno.land/x/oak@v12.5.0/mod.ts";
import { oakCors } from "https://deno.land/x/cors@v1.2.2/mod.ts";
import { verifyLicense } from "./api/license/verify.ts";
import "./services/selfheal.ts";
import "./db/migrate.ts";

const app = new Application();

app.use(oakCors({
  origin: Deno.env.get("CORS_ORIGINS") || "*",
  credentials: true,
}));

const router = new Router();
router.post("/api/license/verify", verifyLicense);

app.use(router.routes());
app.use(router.allowedMethods());

const PORT = 8000;
console.log(`🚀 AUTOMIND läuft auf http://localhost:${PORT}`);
await app.listen({ port: PORT });
