// AUTOMIND API: Lizenz-Verifizierung
import { RouterContext } from "https://deno.land/x/oak@v12.5.0/mod.ts";
import DB from "../../db/client.ts";

export async function verifyLicense(ctx: RouterContext) {
  try {
    const body = await ctx.request.body({ type: "json" }).value;
    const { key } = body;

    if (!key || typeof key !== "string") {
      ctx.response.status = 400;
      ctx.response.body = { error: "Key fehlt oder ungültig." };
      return;
    }

    const row = await DB.query("SELECT tier, valid_until FROM licenses WHERE key = ?", [key]);

    if (!row.length) {
      ctx.response.status = 404;
      ctx.response.body = { valid: false, message: "Key nicht gefunden." };
      return;
    }

    const [tier, validUntil] = row[0];
    const now = Math.floor(Date.now() / 1000);

    if (validUntil && now > validUntil) {
      ctx.response.status = 403;
      ctx.response.body = { valid: false, message: "Key abgelaufen." };
      return;
    }

    ctx.response.body = {
      valid: true,
      tier,
      valid_until: validUntil,
    };
  } catch (err) {
    console.error("❌ Lizenzprüfungsfehler:", err);
    ctx.response.status = 500;
    ctx.response.body = { error: "Interner Fehler." };
  }
}
