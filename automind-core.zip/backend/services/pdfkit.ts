import { PDFDocument, rgb, StandardFonts } from "https://esm.sh/pdf-lib@1.17.1";

export async function generatePDF(): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([600, 700]);
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const { width, height } = page.getSize();

  page.drawText("AUTOMIND Lizenzübersicht", {
    x: 50,
    y: height - 60,
    size: 24,
    font,
    color: rgb(0, 0.53, 0.71),
  });

  page.drawText("📄 Preise:", { x: 50, y: height - 120, size: 14, font });
  page.drawText("BASIC: 4.999 € / 499 € jährlich", { x: 70, y: height - 140, size: 12, font });
  page.drawText("PRO: 9.999 € / 999 € jährlich", { x: 70, y: height - 160, size: 12, font });
  page.drawText("GODMODE: 14.999 € / 1.499 € jährlich", { x: 70, y: height - 180, size: 12, font });

  page.drawText("📜 AGB-Auszug:", { x: 50, y: height - 220, size: 14, font });
  page.drawText("AUTOMIND wird als SaaS bereitgestellt. 12 Monate Mindestlaufzeit.", {
    x: 70,
    y: height - 240,
    size: 10,
    font,
  });

  return await pdfDoc.save();
}
