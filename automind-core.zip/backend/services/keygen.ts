// AUTOMIND Lizenz-Key Generator
export function generateKey(tier: string): string {
  const uuid = crypto.randomUUID();
  console.log(`🔐 Generiere Lizenzkey für ${tier}: AUTOMIND-${uuid}`);
  return `AUTOMIND-${uuid}`;
}
