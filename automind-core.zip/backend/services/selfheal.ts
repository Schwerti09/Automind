import DB from "../db/client.ts";

async function validateAllLicenses() {
  const rows = [...DB.query("SELECT key, valid_until FROM licenses")];
  const now = Math.floor(Date.now() / 1000);
  for (const [key, validUntil] of rows) {
    if (validUntil && now > validUntil) {
      console.log(`❌ Lizenz abgelaufen: ${key}`);
      Deno.exit(1);
    }
  }
}

await validateAllLicenses();

Deno.cron("License Check", "0 0 * * *", async () => {
  await validateAllLicenses();
});
