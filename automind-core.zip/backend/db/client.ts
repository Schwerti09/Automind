import { DB } from "https://deno.land/x/sqlite@v3.7.2/mod.ts";
const db = new DB("licenses.db");
export default db;
