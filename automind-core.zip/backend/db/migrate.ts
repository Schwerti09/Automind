import DB from "./client.ts";

await DB.query(`
CREATE TABLE IF NOT EXISTS licenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT UNIQUE NOT NULL CHECK(key LIKE 'AUTOMIND-%'),
  tier TEXT NOT NULL,
  valid_until INTEGER,
  created_at INTEGER DEFAULT (strftime('%s','now'))
)
`);
