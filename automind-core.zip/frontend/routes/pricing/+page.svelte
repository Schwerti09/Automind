<script lang="ts">
  const plans = [
    {
      name: "BASIC",
      price: "4.999 € / 499 € jährlich",
      description: "1 Instanz, keine Updates, Community Support",
      button: "Jetzt kaufen",
      link: "https://buy.stripe.com/test_1BASIC"
    },
    {
      name: "PRO",
      price: "9.999 € / 999 € jährlich",
      description: "Updates, Self-Healing, E-Mail Support",
      button: "Lizenz sichern",
      link: "https://buy.stripe.com/test_2PRO"
    },
    {
      name: "GODMODE",
      price: "14.999 € / 1.499 € jährlich",
      description: "Alle Module, Whitelabel, Prioritätssupport",
      button: "Unendliche Macht",
      link: "https://buy.stripe.com/test_3GOD"
    }
  ];
</script>

<style>
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }
  .card { padding: 2rem; border: 1px solid #ccc; border-radius: 12px; background: white; text-align: center; }
  .card h2 { margin: 0.5rem 0; }
  .card button { margin-top: 1rem; padding: 0.75rem 1.5rem; font-weight: bold; }
</style>

<h1>🚀 AUTOMIND Lizenzmodelle</h1>
<div class="grid">
  {#each plans as plan}
    <div class="card">
      <h2>{plan.name}</h2>
      <p><strong>{plan.price}</strong></p>
      <p>{plan.description}</p>
      <a href={plan.link} target="_blank">
        <button>{plan.button}</button>
      </a>
    </div>
  {/each}
</div>
