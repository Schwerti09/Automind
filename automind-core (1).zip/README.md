# AUTOMIND Core

Dies ist das saubere Basisprojekt für den Deploy.